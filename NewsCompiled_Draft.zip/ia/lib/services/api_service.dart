import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ia/model/article_model.dart';
import 'package:ia/pages/search_page.dart';

class ApiService extends SearchPage {
  final endPointUrl = "newsapi.org";
  final client = http.Client();

  Future<List<Article>> getArticle() async {
    final queryParameters = {
      'domains':
          'foreignpolicy.com, foreignaffairs.com, economist.com, theconversion.com, theguardian.com, france24.com',
      'sortBy': 'publishedAt',
      //the 'q' paramter will be changed with the user input from SearchPage
      'q': '$input',
      'apiKey': 'dff5d783b11e4bd18c11840864c2f32e'
    };

    final uri = Uri.https(endPointUrl, '/v2/everything', queryParameters);
    final response = await client.get(uri);
    Map<String, dynamic> json = jsonDecode(response.body);
    List<dynamic> body = json['articles'];
    List<Article> articles =
        body.map((dynamic item) => Article.fromJson(item)).toList();
    return articles;
  }
}
