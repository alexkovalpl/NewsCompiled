import 'package:flutter/material.dart';
import 'package:ia/pages/home_page.dart';
import 'package:ia/services/api_service.dart';

class SearchPage extends StatelessWidget {
  SearchPage({Key key}) : super(key: key);

  String input = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.red,
          title: Container(
            width: double.infinity,
            height: 40,
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(5)),
            child: Center(
              child: TextField(
                onChanged: (String text) {
                  input = text;
                },
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    suffixIcon: IconButton(
                      icon: Icon(Icons.search),
                      onPressed: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => HomePage())),
                    ),
                    hintText: 'Search Articles',
                    border: InputBorder.none),
              ),
            ),
          )),
    );
  }
}
